p=(10,20,30)
print(*p,sep=",")

def test(*arg):
    print(arg)
    for i in arg:
        print(i)

test(10,40,50)

def fun(p1,p2,*argss,k,**kargs):
    print(p1,p2)
    print(argss)
    print(k)
    print(kargs)
fun(10,20,50,60,70,79,k=3,k1=7,k2=8,k3=8)
