def palindrome(string):
    '''
    Get an string from the standard input(stdin)

    The function will continue looping until the all the elements of the string is appended to new string

    :param string: The string that the user will see when they are prompted to enter the value
    :return: reverse of the string that the user enters

    '''
    j=""
    for i in string:
        if i.isalnum():
            j=j+i

    if(j.casefold()==j[::-1].casefold()):
       return("'{}'is palindrome".format(j))
    else:
        return("'{}'is not palindrome".format(string))
string=input("Enter the string ")
t=palindrome(string)
print(t)


help(palindrome)

'''def palindrome(string):
    j=""
    u=""
    for i in string:
        if i.isalnum():
            j=j+i
            
    for i in range(len(j)-1,-1,-1):

       u=u+string[i]

    if(u.casefold()==j.casefold()):
        return("'{}'is palindrome".format(string))
    else:
        return("'{}'is not palindrome".format(string))
string=input("Enter the string ")
t=palindrome(string)
print(t)'''

#palindrome of number

def palin(number):
    rev=0
    while number!=0:
        rem=number%10
        rev=(rev*10)+rem
        number=number//10
    print(rev)
number=int(input("enter the number"))
palin(number)
#amstrong
def amstrong(number):
    temp=number
    s=0
    while temp!=0:
        rem=temp%10
        s=s+(rem**3)
        temp=temp//10
    print(s)
number=int(input("enter the numbers"))
amstrong(number)