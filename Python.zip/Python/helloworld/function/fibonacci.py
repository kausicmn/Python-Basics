def fibonacci(n :int, a=0, b=1)-> int:
    """Returns the `n` fibonacci number for positive number`n`"""
    if n <= 0 or n <= 1:
        return (n)
    c = a + b
    for i in range(2, n):
        a = b
        b = c
        c = a + b

    return (c)


n = int(input("enter the number "))
t = fibonacci(n)
print(t)

for i in range(36):
    print(i, fibonacci(i))
