str=input()
t="aeiou"
poa=""

# for i in str:
#    if i in t or i==" " :
#       continue
#
#    else:
#       u=u+i
#       print(u)
d=0
for i in range(0,len(str)):
   for j in range(0,len(t)):
      if(str[i]==t[j] or str[i]==" "):
         d=1
   if d==0:
      u=u+str[i]


   d=0
print(u)
for f in u:
   print(f)


t=sorted(set(u.casefold()))
print(t)


vowels=frozenset("aeiou")

s=set(str).difference(vowels)

print(s)



