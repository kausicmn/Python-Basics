setz={"cow","fox","monkey","elephant"}
#print(setz)

#for i in setz:
    #print(i)

sett=set(["lion","tiger","giraffe","pig"])
#print(sett)

empty=set()
empty.add("a")
print(empty)

setz.add("pig")
#print(setz)
#print(setz.union(sett))
print(setz.intersection(sett))

even=set(range(0,40,2))
square=(4,16)
squares=set(square)

# print(even)
# print(sorted(even))
# #print(sorted(even.difference(squares))) #removes common element (4 and 16 common to squares)
# print(squares-even)
#
# even.difference_update(squares)
# print(even)
# print(even.symmetric_difference(square))
# squares.remove(16)
# print(squares)
# squares.discard(6)
if squares.issubset(even):
    print("i")
if even.issuperset(square):
    print("j")

fr=frozenset(range(0,20,2))
print(fr)
#fr.add(3)