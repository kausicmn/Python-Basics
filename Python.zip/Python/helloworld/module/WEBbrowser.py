import webbrowser
# webbrowser.open("https://www.facebook.com/")

chrome=webbrowser.get('C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s').open("https://www.facebook.com/")
