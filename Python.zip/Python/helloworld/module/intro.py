from  turtle import *
#import time
forward(150)
right(250)
forward(150)
circle(100)
#time.sleep()
done()