num=[1,2,3,4,5,6]

squares=[n**2 for n in num]
print(squares)