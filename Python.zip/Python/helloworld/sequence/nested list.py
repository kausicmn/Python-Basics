e=[2,4,6,8]
o=[1,3,5,7]
m=[e,o]
print(m)
for i in m:
    print(i)
    for j in i:
        print(j)