k=[8,6,6,7,3,3,5,6,4,2]
'''for i in k:
    #print (i)
    if i==6:
        k.remove(6)
        continue
print (k)'''
n=len(k)
i=0
while(i<n):
    if k[i]==6:
        k.remove(k[i])
        n=n-1
        continue
    i+=1
print (k)