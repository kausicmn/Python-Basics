'''computer_parts=["mouse","keyboard","monitor","hard disk"]
#computer_parts[2]="CPU"
print(computer_parts)
computer_parts[2:]
print(computer_parts)
computer_parts[2:]="CPU"
print(computer_parts)

computer_parts[2:]=["CPU"]
print(computer_parts)'''

#data=[4,5,104,145,110,120,130,150,160,170,183,185,197,291,350,360]
#data=[104,145,110,120,130,150,160,170,183,185,197]
data=[1011,1022,1033,1044,1055]
n=len(data)
i=0
while i<n:
    if(data[i]<=100 or data[i]>=200):
        del data[i]
        n=n-1
        continue
    i=i+1

print(data)
'''min=100
max=200
stop=0
start=0
for index,value in enumerate(data):
    if value>=min:
        stop=index
        break






del data[:stop]


print(data)

for i in range (len(data)-1,-1,-1):
    if data[i]<=max:
        start=i+1
        break
print(start)


del data[start:]
print(data)'''
