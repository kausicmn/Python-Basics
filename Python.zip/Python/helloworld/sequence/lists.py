'''e=[2,4,6,8,6]
o=[1,3,5,7]

print(min(e))
print(max(o))
print(e.count(6))
print("mississipi".count("s"))

for index,char in enumerate("abcdef"):
    print(index + 1,char)

o.sort(reverse=True)
print(o)
e.extend(o)
print(e)
e.sort()
print(e)

o.append(10)
print(o) '''
o=[1,3,5,7]
n=len(o)

'''for i in range(0,len(o)):
    print(o[i])
    if o[i]==1:
        o.remove(o[i])
        n=n-1
print (o)'''
#print(e)
f=[1,2,3,4,5,6,6,7,8]
h=[9,7,8,9,8,2,9,2,7,3]
k=[8,6,6,7,3,3,5,6,4,2]
for i in k:
    #print (i)
    if i==6:
        k.remove(6)
        continue
print (k)
'''for j in range(0,len(f)):
    #print(e[j])
    if f[j] == 1:
       f.remove(f[j])
print(f)'''
w=sorted(h,reverse=True) #prints sorted item in new list
print(w)
q= h.sort()
print(q)

d="He is a good boy"
x=sorted(d,key=str.casefold)
print(x)
l=["adam","nova",'king','Fury']
l.sort(key=str.casefold)
print(l)
# diiferent ways of creating list
b=list("1234567")
print(b)

v=list(h)
print(v)

a=h[:]
print(a)

s=h.copy()
print(s)