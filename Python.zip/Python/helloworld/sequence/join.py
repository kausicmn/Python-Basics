flower = ["sunflower", "daffodill", "rose", "jasmine", "hibiscus"]
separator="|"
print(separator.join(flower)) #join converts list to strings
print(",".join(flower))

q="he is a good boy"
print(q.split(' ')) # split converts string to list

list=['9','273','372','036','854','775','807']
l=[]
for i in range(len(list)):
 list[i]=int(list[i])

print(list)

for i in list:
 l.append(int(i))
print(l)


