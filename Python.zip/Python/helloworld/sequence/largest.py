'''list=[]
n=int(input("enter the number of elements"))
for i in range(0,n):
    t=int(input("enter the list of numbers"))
    list.append(t)
for i in range(0,len(list)):
    for j in range(0,i+1):
        if list[i]<list[j]:
            temp=list[i]
            list[i]=list[j]
            list[j]=temp
print(list)
print("the largest number is ",list[len(list)-1])'''

data=[4,5,104,145,110,120,130,150,160,170,183,185,197,291,350,360]
for i in range (len(data)-1,-1,-1):
    if data[i]<=100 or data[i]>=200:
        del data[i]



print(data)

e=[2,4,6,8,6]
h=[9,7,8,9,8,2,9,2,7,3]

for j in range(len(h)-1,-1,-1):
    #print(e[j])
    if h[j] == 9:
        h.remove(h[j])
print(h)
