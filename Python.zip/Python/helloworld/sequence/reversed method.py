h=[9,7,8,9,8,2,9,2,7,3]
for index,value in enumerate(reversed(h)):
    print(index,value)
data=[4,5,104,145,110,120,130,150,160,170,183,185,197,291,350,360]
top_index=len(data)-1
for index,value in enumerate(reversed(data)):
    if data[top_index-index]<=100 or data[top_index-index]>=200:
        print(top_index-index,value)
        del data[top_index-index]
print(data)