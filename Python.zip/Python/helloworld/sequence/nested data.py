albums = [
    ("Welcome to my Nightmare", "Alice Cooper", 1975,
     [
         (1, "Welcome to my Nightmare"),
         (2, "Devil's Food"),
         (3, "The Black Widow"),
         (4, "Some Folks"),
         (5, "Only Women Bleed"),
     ]
     ),
    ("Bad Company", "Bad Company", 1974,
     [
         (1, "Can't Get Enough"),
         (2, "Rock Steady"),
         (3, "Ready for Love"),
         (4, "Don't Let Me Down"),
         (5, "Bad Company"),
         (6, "The Way I Choose"),
         (7, "Movin' On"),
         (8, "Seagull"),
     ]
     ),
    ("Nightflight", "Budgie", 1981,
     [
         (1, "I Turned to Stone"),
         (2, "Keeping a Rendezvous"),
         (3, "Reaper of the Glory"),
         (4, "She Used Me Up"),
     ]
     ),
    ("More Mayhem", "Imelda May", 2011,
     [
         (1, "Pulling the Rug"),
         (2, "Psycho"),
         (3, "Mayhem"),
         (4, "Kentish Town Waltz"),
     ]
     ),
]

h=albums[2][3][3][1]
print(h)

while True:


    print("enter the album number \n"
          "1 ",albums[0][0],"\n",
          "2 ",albums[1][0],"\n",
          "3 ",albums[2][0],"\n",
          "4 ",albums[3][0],"\n")
    i=int(input())
    if i>len(albums) or i<1:
        break
    else:
        if i==1:
            print(albums[0][3])
            num=int(input("Enter the song number to add in jukebox"))
            if num==1:
                print(albums[0][3][0][1], "is playing")
            if num==2:
                print(albums[0][3][1][1], "is playing")
            if num==3:
                print(albums[0][3][2][1], "is playing")
            if num==4:
                print(albums[0][3][3][1], "is playing")
            if num==5:
                print(albums[0][3][4][1], "is playing")
            print("*"*40)


        elif i==2:
            print(albums[1][3])
            num=int(input("Enter the song number to add in jukebox"))
            if num==1:
                print(albums[1][3][0][1], "is playing")
            if num==2:
                print(albums[1][3][1][1], "is playing")
            if num==3:
                print(albums[1][3][2][1], "is playing")
            if num==4:
                print(albums[1][3][3][1], "is playing")
            if num==5:
                print(albums[1][3][4][1], "is playing")
            if num==6:
                print(albums[1][3][5][1], "is playing")
            if num==7:
                print(albums[1][3][6][1], "is playing")
            if num==8:
                print(albums[1][3][7][1], "is playing")
            print("*"*40)

        elif i==3:
            print(albums[2][3])
            num=int(input("Enter the song number to add in jukebox"))
            if num==1:
                print(albums[2][3][0][1], "is playing")
            if num==2:
                print(albums[2][3][1][1], "is playing")
            if num==3:
                print(albums[2][3][2][1], "is playing")
            if num==4:
                print(albums[2][3][3][1], "is playing")
            print("*"*40)
        elif i==4:
            print(albums[3][3])
            num=int(input("Enter the song number to add in jukebox"))
            if num==1:
                print(albums[3][3][0][1], "is playing")
            if num==2:
                print(albums[3][3][1][1], "is playing")
            if num==3:
                print(albums[3][3][2][1], "is playing")
            if num==4:
                print(albums[3][3][3][1], "is playing")
            print("*"*40)

