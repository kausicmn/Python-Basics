menu = [
    ["egg", "bacon"],
    ["egg", "sausage", "bacon"],
    ["egg", "spam"],
    ["egg", "bacon", "spam"],
    ["egg", "bacon", "sausage", "spam"],
    ["spam", "bacon", "sausage", "spam"],
    ["spam", "sausage", "spam", "bacon", "spam", "tomato", "spam"],
    ["spam", "egg", "spam", "spam", "bacon", "spam"],
]

for i in menu:
    for j in i[::-1]:
        if "spam" in i:
            i.remove("spam")
print(menu)

for i in menu:
    for j in range(len(i)-1,-1,-1):
        if i[j]=="spam":
            del(i[j])
print(menu)

for i in menu:
    for j in i:
        if j!="spam":
            print(j,end=", ")
    print()

print("name","age","dob",sep=", ")
