x=2147395599
t=1
if (x == 0 or x == 1):
    print(x)
i=1
result=1
while(result<=x):
    i=i+1
    result=i*i
print(i-1)
