a=[[1]]
l=[1,1]
a.append(l)
print(a)