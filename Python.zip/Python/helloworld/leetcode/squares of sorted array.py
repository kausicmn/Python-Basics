nums = [-4,-1,0,3,10]


l=[i*i for i in nums]
l.sort()
print(l)