
def k(o):
    t=[]
    g=0
    for i in range(0,len(o)-1):
        if words in o:
            t.append(o)


    return(t)

a=["qwertyuiop"]
b=["asdfghjkl"]
c=["zxcvbnm"]

i=1
t=""

words = ["Hello","Alaska","Dad","Peace"]
z=k(a)
while i<=2:
    if t=="":
        z=k(b)
        b=c
        i=i+1
    else:
        print(z)
        break




