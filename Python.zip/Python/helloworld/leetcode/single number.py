nums = [4,1,2,1,2]

for i in nums:
    if nums.count(i)==1:
        print(i)





