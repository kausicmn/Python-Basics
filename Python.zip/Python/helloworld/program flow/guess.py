import random
answer = random.randint(1,10)
n=0
guess=int(input())
while(guess !=0):

    if guess==answer:
        print("you have guessed it correctly",guess)
        break
    elif guess<answer:
        print("guess higher")
        guess=int(input())
   

    elif guess>answer:
        print("guess lower")
        guess=int(input())
    n=n+1

print(n)





