def pushZerosToEnd(input1, input2):
    count = 0
    for i in range(input2):
        if input1[i] != 0:


            input1[count] = input1[i]
            count+=1



    while count < input2:
        input1[count] = 0
        count += 1
    return(input1)


# Driver code
input1 = [5,0,7,6]
input2= len(input1)
v=pushZerosToEnd(input1, input2)
print("Array after pushing all zeros to end of array:",v)


