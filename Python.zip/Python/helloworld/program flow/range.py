for i in range(0,10,5):
    print("value of i is",i)
    print("value of i is {}".format(i))

list=["a","b","c",'d',"e","f"]

for i in list:
    if i == "c":
        continue
    print(i)
t= None
for i in range(len(list)):

    if list[i] == "h":
        t=i
        break
print(t)

