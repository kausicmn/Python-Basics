
low=1
high=1000
g=0
mid=0
while low!=high:
    mid=(high+low)//2
    print(mid)
    guess=(input("enter high or low or c"))
    if(guess=="h"):
        low=mid+1
    elif(guess== "l" ):
        high=mid-1
    elif (guess== "c"):
        print("found")
        break
    else:
        print("enter h or l or c")
    g+=1
else:
    print("the number is ", low,"guesses=",g)



