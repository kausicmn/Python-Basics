number="122,456;32;99;043"
s=""
t=0
for i in number:
    if i.isnumeric():
        s=s+i

print(s)

for i in s:
    t=t+int(i)
print(t)

