# n=int(input("Enter the number"))
n="-"
while n!="0":

    if n in "12345":
        print("choice is",n)
    else:
        print("enter the choice \n"
              "1.Learn python \n"
              "2.Learn java \n"
              "3.Go swimming \n"
              "4.Have dinner \n"
              "5.Go to bed \n"
              "0.Exit")
    n=(input("Enter the number "))



