exit=["n","e","w","s"]

choose=""
while choose not in exit:
    choose=input("enter the way")
    if choose == "quit":
        print("exit")
        break