colour=input()

if "blue" in colour.casefold(): # same for not in
    print("content is present")
