n=[18,29,16,41]

for i in n:
    if i%8==0:
        print("the number is divisible by 8 and the number is {}".format(i))
        break
else:
    print("not divisible")