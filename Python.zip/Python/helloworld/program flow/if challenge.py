age=int(input("enter your age"))
if age>=18 and age<=30:
    print("you are ready",age)
else:
    print("not ready")
