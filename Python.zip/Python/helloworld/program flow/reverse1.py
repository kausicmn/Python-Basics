strng=input()
str=""
j=len(strng) -1
for i in range(len(strng)):
    str=str+strng[j]
    j=j-1
print(str)

strngs=strng[::-1]
print(strngs)


