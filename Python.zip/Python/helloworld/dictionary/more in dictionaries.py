Dictionary={"Apple":"A",
            "Mango":"M",
            "Banana":"B",
            "Orange":"O",
            "Grapes":"G",
            "Apple":"J"}

veg={"Potato":"P",
     "Beetroot":"B",
     "Carrot":"C",
     "Cabbage":"ca",
    }

veg.update(Dictionary)
print(veg)

dd=veg.copy()
print(dd)
dd.update(veg)
print(dd)