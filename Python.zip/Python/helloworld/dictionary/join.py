list=[1,2,3,4,5,6,7,8]
li=["a","b","c","d"]
new=""
for i in list:
    new=new+str(i)
print(new)

neww=",".join(str(new))
print(neww)

ss=",".join(li)
print(ss)
