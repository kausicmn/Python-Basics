Dictionary={"Apple":"A",
            "Mango":"M",
            "Banana":"B",
            "Orange":"O",
            "Grapes":"G",
            "Apple":"J"}
'''
print(Dictionary)
print(Dictionary["Mango"])
print(Dictionary)
Dictionary["Pomogranate"]="p"

del Dictionary["Mango"]
print(Dictionary)



while True:
    n=input("enter the key")
    if n=="quit":
        break
    d=Dictionary.get(n,"\"Wrong key\"\"{}\"".format(n))
    print(d)
   # if n in Dictionary:
     #   s=Dictionary.get(n)
     #   print(s)
    #else:
     #   print("wrong key")
for j in range(10):
    for i in Dictionary:
        print(Dictionary[i])
print()
ordered_keys=sorted(list(Dictionary))
for f in ordered_keys:
    print(Dictionary[f])
'''

print(Dictionary.values())
print(Dictionary.keys())
print(Dictionary.items())

tup=tuple(Dictionary.items())
print(tup)

for i in tup:
    j,k=i
    print("item is",j,"description is",k)
print(dict(tup))