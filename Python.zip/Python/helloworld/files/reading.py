# file=open("C:\\Users\\kausi\\Desktop\\1.txt", 'r')
#
# for i in file:
#     print(i)
# file.close()
#
# for j in i:
#     print(j)

with open("C:\\Users\\kausi\\Desktop\\1.txt", 'r') as file:
    i=file.readlines() #prints in list
print(i)
for j in i:
    print(j)
l=[]
for t in j[::-1]:
    l.append(t)
print(l)


y="".join(l)

#d=y.split()
#print(d)
g=""
for i in y:
    if i not in g:
        g=g+i
print(g)
d=g.split()
print(d)