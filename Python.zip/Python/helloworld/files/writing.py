c=["a","b","c","d","e"]

with open("cc.txt","w") as alphabets:
    for i in c:
        print(i,file=alphabets)
cc=[]
with open("cc.txt","r") as alphabets:
    for i in alphabets:
        cc.append(i.strip("\n"))
print(cc)

for q in cc:
    print(q)

print("kausic".strip("k")) #removes character from first and last of word


