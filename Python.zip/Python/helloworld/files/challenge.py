with open("sample.txt","w") as sample:
    for i in range(1,2):
        for j in range(1,12):
            print(j,"times",i,"is",i*j,"\n",file=sample)
        print("*"*20,file=sample)

with open("sample.txt","a") as sample:
    for i in range(2,13):
        for j in range(1,13):
            print(j,"times",i,"is",i*j,"\n",file=sample)
        print("*"*20,file=sample)

