s=input()
j=[]

count=0
max_count=0

for i in s:
    if i not in j:
        j.append(i)
        count=len(j)
        if count>max_count:
            max_count=count

    else:
        j[:j.index(i)+1]=[]
        j.append(i)
        count=0
print(max_count)


