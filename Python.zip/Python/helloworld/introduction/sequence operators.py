string1="he "
string2="is "
string3="a "
string4="good boy"
print(string1 + string2 + string3 + string4)
print("he " "is " "a " "good boy")
print("hello \n" *5)
print("hello \n" *(5+4))
today="wednesday"
print("day" in today)
print("thur" in today)
print("wed"in today)