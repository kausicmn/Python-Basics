def multi (p,n):
    sum=0
    for i in range(0,p+1):
        sum=sum+(n*i)
    #print (sum)
    avg=(sum//p)
    print(avg)
p = int ( input () )
n=int(input())
multi(p,n);

