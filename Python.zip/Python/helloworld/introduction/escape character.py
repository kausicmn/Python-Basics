splitstring="\n how are you\n are you fine\n hello \t world "
print(splitstring)
split="the shop owner said he is \"resting\"" ## same for single quotes
print(split)
ss="""I "am going" to learn 'python 3.3' in a easy way"""
print(ss)
sss=""" the string
has been
split 
in lines"""
print(sss)
sss=""" the string \
has been \
split \
in lines"""
print(sss)

print("C:\\Users\\tim\\notes.txt")
print("C:\\Users\\timbuchalka\\notes.txt")

age=21
print(age)
print(type(age))
print(type(sss))
age="21 years"
print(age)
print(type(age))
print(ss + sss) ## can only concat two objects of same datatype
