def re():
    x= int(input())
    rev=0
    t=1
    if x < 0:
        t=0
        x=-x
        print(x)
    while(x!=0):
        rem=x%10
        rev=(rev*10)+rem
        x=x//10
    if t==0:
        return (-rev)
    else:
        return rev

t=re()
print(t)