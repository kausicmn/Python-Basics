for i in range(1,13):
    print("number is {0} and square is {1} and cube is {2}".format(i,i**2,i**3))
print()
for i in range(1,13):
    print("number is {0:2} and square is {1:<2} and cube is {2:^2}".format(i,i**2,i**3))
    # < left align > right align  ^ center align  :2 leaves two space gap

print()

print("the value of pi is {0:12}".format(22/7))
print("the value of pi is {0:12f}".format(22/7))
print("the value of pi is {0:50f}".format(22/7))
print("the value of pi is {0:12.50f}".format(22/7)) # prints 50 numbers after decimal
print("the value of pi is {0:52.50f}".format(22/7))
print("the value of pi is {0:<62.50f}".format(22/7))
print("the value of pi is {0:<62.54f}".format(22/7))
print("the value of pi is {:12}".format(22/7)) #works without field number

age = 24
print(f"my age is {age} years") # fstring
print(f"the value of pi is {22/7:12.50f}") # variables can also be used instead of expression
