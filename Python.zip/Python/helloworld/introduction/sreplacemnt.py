age=24
print("my age is",age,"years")

print("my age is " + str(age) + " years")
print("my age is {0} years".format(age))
print("there are {0} days in a week and they are {1} ,{2} ,{3}".format(7,"mon","tue","wed"))
# it can be used multiple times where {0} can be used again to represent 7
print(f"my age is {age} years") # fstring
