

def sum(n):
    j=0


    for i in range(0,n+1):
        if i%2 == 0:
            j=j+i
    print(j)
n = int(input("enter the number"))
sum(n);



