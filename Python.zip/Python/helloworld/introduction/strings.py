parrot = "Norwegian Blue"
print(parrot + "\n" + parrot[3] + "\n" + parrot[4] + "\n" + parrot[9] + "\n" + parrot[3] + "\n" + parrot[6] + "\n" + parrot[8])
print(parrot[1:6])
print(parrot[:3] + parrot[3:] )
print(parrot[:])
print(parrot[-8:-2])
print(parrot[-2:4]) #prints nothing

print(parrot[0:8:2])
number= "99,23:25,89!21"
s=number[2::3]
print(number[2::3])
v="".join(char if char not in s else " " for char in number).split()
print([int(i) for i in v])

