n=int(input("Enter the number"))
flag=1
if n>1:
    for i in range(2,n//2):
        if n % i ==0:
            print("number is not prime")
            break
    else:
        print("number is prime")

else:
    print("number is not prime")










