# def pali():
#     x=int(input())
#     rev=0
#     temp=x
#     while x>0 and -2**31 < x < 2**31-1:
#         rem=x%10
#         rev=(rev*10)+rem
#         x=x//10
#     print(rev)
#     if(rev==temp and temp>0):
#         return("true")
#     elif(rev!=temp or temp<=0):
#         return("false")
# t=pali()
# print(t)

x=int(input())

e=str(x)
t=""

for i in range(len(e)-1,-1,-1):
    t=t+str(e[i])
print(t)

if(e==t):
    print("true")
else:
    print("false")

