n=int(input("enter the number "))


def rev(n):
    t=0
    if n>1:
        if(n==2):
            print("prime")
            t=n
        else:

            for i in range(2,n):

                if(n%i==0):
                    print("number is not prime")
                    t=-1

                    break
                else:

                    t=n
                    global s
                    s=1

    else:
        print("not prime")
        t=-1

    return t



def isprime(u):


    f=u%10
    c=u//10
    # print(c)
    global m
    m=f+c
    global s
    s=0
    #print(m)
    return m
u=rev(n)
if(u>0):
    z=isprime(u)

    rev(z)
    if(s==1):
        print("prime")