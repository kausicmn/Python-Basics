letters="abcdefghijklmnopqrstuvwxyz"
print(letters[16:13:-1])
print(letters[4::-1])
print(letters[:-9:-1])
print(letters[-1:])
print(letters[:1])